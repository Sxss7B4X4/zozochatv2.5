import tkinter as tk
import os


form=tk.Tk()
form.title('ZozoChat V2.5')
form.geometry('450x245')
form.resizable(False,False)
yazi=tk.Label(form,text='ZozoChatV2.5 IRC Chata Hoşgeldiniz.',font='serif 15')
yazi.pack()
# Bu Kisim Ise Verileri Printe Donusturuyor



def receive():
    entry2=ent1.get()
    entry=ent2.get()
    print(entry2,':',entry)

def cu():
    print('You Founded A Easteregg')


def temizle():
    os.system('cls')

def kul():
    klavuz=tk.Tk()
    klavuz.title('Kullanma Klavuzu')
    klavuz.geometry('450x140')
    tal1=tk.Label(klavuz,text='1 - Programi Acin').pack()
    tal2=tk.Label(klavuz,text='2 - Kullanici Adinizi Ve Sifrenizi Belirtiniz').pack()
    tal3=tk.Label(klavuz,text='3 - Enter Tusuna Basiniz').pack()
    tal4=tk.Label(klavuz,text='4 - Eger Chati Silmek Isterseniz Chati Temizle Butonuna Dokununuz').pack()
    tal5=tk.Label(klavuz,text='5 - Bir Ihtiyaciniz Olur Ise pedoshop@outlook.com a Mesaj Gonderiniz').pack()
    klavuz.mainloop()

kulklavuz=tk.Button(form,text='Nasil Kullanilir ?',width='11',heigh='1',font='serif 10',bg='black',fg='yellow',command=kul).pack(side='bottom')

# Asagi Kisimda Veriler Verilip ent1 Adli Stringden Aliniyor
talimat1=tk.Label(form,text='Isim : ')
talimat1.pack()
ent1=tk.Entry(width=20,fg='red',bg='black',font='serif 15',)
ent1.pack()
talimat2=tk.Label(form,text='Mesaj : ')
talimat2.pack()
ent2=tk.Entry(width=30,fg='purple',bg='black',font='serif 15')
ent2.pack()

tus3=tk.Button(form,text='Chati Temizle',bg='black',fg='blue',command=temizle)
tus3.pack()
img = tk.PhotoImage(file="Enter.png")
tus=tk.Button(form,text='Enter',font='serif 10', command=receive,width='120',heigh='30',image = img)
tus.pack()
# Burada Ise Veri Alma Islemi Bitiyor Ve Detaylar Geliyor
telif=tk.Label(form,text='© Butun Telif Haklari Zozo Group a Saklidir ©',font='serif 8')
telif.pack()
form.mainloop()
# Made By RootManX#7356
